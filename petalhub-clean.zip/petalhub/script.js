(function(){
  "use strict";

  /* ---------- data ---------- */
  var FLOWERS = [
    { id: 1, name: "White Roses", price: 18, petals: 8, color: "#F3EEE8", tag: "Bestseller", desc: "Full, ruffled ivory-white blooms with softly blushed centers — a graceful classic, sold by the bunch of six stems.", stock: "Checking stock\u2026", image: "flowers/rose.jpg", photoAlt: "Ivory-white roses with softly blushed centers", weather: ["sunny", "cloudy"] },
    { id: 2, name: "Tulip", price: 12, petals: 6, color: "#C9707A", tag: "Seasonal", desc: "Clean, cup-shaped blooms just opening, prized for their simple, elegant silhouette.", stock: "Checking stock\u2026", image: "flowers/tulip.jpg", photoAlt: "A red tulip with a smooth cup-shaped bloom", weather: ["sunny", "cloudy"] },
    { id: 3, name: "Sunflower", price: 9, petals: 14, color: "#D9A441", tag: "Cheerful", desc: "Bold, sun-facing blooms with a deep centre — an instant lift for any room.", stock: "Checking stock\u2026", image: "flowers/sunflower.jpg", photoAlt: "A sunflower with a textured dark center", weather: ["sunny"] },
    { id: 4, name: "Peony", price: 22, petals: 10, color: "#E3AEB4", tag: "Limited", desc: "Lush, layered petals with a soft scent — a favourite for spring arrangements.", stock: "Checking stock\u2026", image: "flowers/peony.jpg", photoAlt: "A full pink peony with overlapping petals", weather: ["cloudy", "rainy"] },
    { id: 5, name: "Orchid", price: 28, petals: 5, color: "#9C6FA8", tag: "Exotic", desc: "Elegant, long-lasting blooms with a sculptural, architectural form.", stock: "Checking stock\u2026", image: "flowers/orchid.jpg", photoAlt: "Purple and white orchid blooms", weather: ["cloudy", "rainy"] },
    { id: 6, name: "Lily", price: 16, petals: 6, color: "#F2F0E4", tag: "Fragrant", desc: "Trumpet-shaped blooms with a heady scent — striking in tall arrangements.", stock: "Checking stock\u2026", image: "flowers/lily.jpg", photoAlt: "A white Madonna lily with visible stamens", weather: ["rainy"] },
    { id: 7, name: "Red Roses", price: 32, petals: 8, color: "#A93342", tag: "Romantic", desc: "A hand-tied dozen of velvety red roses, chosen for their rich color and lasting impression.", stock: "Checking stock\u2026", image: "flowers/red-roses-bouquet.jpg", photoAlt: "Velvety red roses arranged in a bouquet", weather: ["sunny", "cloudy"] },
    { id: 8, name: "Carnation", price: 14, petals: 12, color: "#D77A86", tag: "Long-lasting", desc: "Softly ruffled stems with a gentle, clove-like scent and a long vase life.", stock: "Checking stock\u2026", image: "flowers/carnation-bouquet.jpg", photoAlt: "Soft pink carnations with ruffled petals", weather: ["cloudy", "rainy"] },
    { id: 9, name: "Chrysanthemum", price: 18, petals: 16, color: "#E3AEB4", tag: "Full-bloom", desc: "A generous spray of layered blooms that brings lasting color to any arrangement.", stock: "Checking stock\u2026", image: "flowers/chrysanthemum.jpg", photoAlt: "A full pink chrysanthemum in bloom", weather: ["cloudy", "rainy"] },
    { id: 10, name: "Gladiolus", price: 20, petals: 6, color: "#D77988", tag: "Statement", desc: "Tall, elegant flower spikes that add graceful height and color to a bouquet.", stock: "Checking stock\u2026", image: "flowers/gladiolus.jpg", photoAlt: "A tall gladiolus flower spike", weather: ["sunny"] }
  ];
  var WRAPPING_DESIGNS = [
    { id: "pink-elegance", name: "Pink Elegance", color: "Blush pink", price: 75, detail: "Premium pink matte wrapping paper with satin ribbon.", image: "https://i.pinimg.com/1200x/10/3a/b7/103ab76c85c18521d5ba2addbd7689af.jpg" },
    { id: "classic-kraft", name: "Classic Kraft", color: "Natural brown", price: 50, detail: "Eco-friendly brown kraft paper with natural jute twine.", image: "https://i.pinimg.com/originals/a4/83/86/a48386d024d02f316231bb5b8635798f.png" },
    { id: "midnight-luxury", name: "Midnight Luxury", color: "Midnight navy", price: 80, detail: "Dark navy blue waterproof wrapping with gold ribbon accents.", image: "https://i.pinimg.com/736x/75/91/1e/75911ef1eea4d5bae6547dfc00504a82.jpg" },
    { id: "minimalist-white", name: "Minimalist White", color: "Clean white", price: 45, detail: "Clean white tissue paper with pastel ribbon.", image: "https://i.pinimg.com/736x/23/e6/57/23e657e50be60d5c493b63c62614aa92.jpg" }
  ];
  // Occasion records reference product IDs so FLOWERS remains the single product source of truth.
  var OCCASIONS = [
    { month: 2, day: 14, name: "Valentine's Day", message: "Flowers for someone special.", recommendedFlowerIds: [1, 2, 4] },
    { month: 12, day: 25, name: "Christmas", message: "Bring a little seasonal color to someone’s home.", recommendedFlowerIds: [3, 5, 6] },
    { month: 1, day: 1, name: "New Year's Day", message: "Start the year with something bright and beautiful.", recommendedFlowerIds: [1, 3, 6] }
  ];
  // Seasonal recommendations use Philippine seasons (matching the Ilocos Sur branch): dry season vs rainy season.
  var SEASONS = [
    { id: "dry", name: "Dry Season", months: [11, 12, 1, 2, 3, 4], message: "Sun-loving blooms that thrive in the dry season.", recommendedFlowerIds: [3, 2, 1] },
    { id: "wet", name: "Rainy Season", months: [5, 6, 7, 8, 9, 10], message: "Lush, long-lasting blooms suited to the rainy season.", recommendedFlowerIds: [5, 6, 4] }
  ];
  function currentSeason(date){
    var month = date.getMonth() + 1;
    return SEASONS.filter(function(season){ return season.months.indexOf(month) !== -1; })[0] || SEASONS[0];
  }
  // Weather has no live data source in this front-end build, so the visitor simulates
  // today's weather with the toggle in the recommendations panel instead of calling a real weather API.
  var WEATHER_PRESETS = [
    { id: "sunny", label: "Sunny", message: "Bright, cheerful blooms for a sunny day.", recommendedFlowerIds: [3, 2, 1] },
    { id: "rainy", label: "Rainy", message: "Bring some color indoors on a rainy day.", recommendedFlowerIds: [5, 6, 4] },
    { id: "cloudy", label: "Cloudy", message: "Soft, gentle tones for an overcast day.", recommendedFlowerIds: [1, 4, 6] }
  ];
  function loadCart(){
    try { var c = JSON.parse(sessionStorage.getItem("ph.cart") || "[]"); return Array.isArray(c) ? c.filter(function(l){ return l && l.qty > 0 && (l.id || (l.arrangementType === "custom" && Array.isArray(l.flowers) && l.flowers.length)); }) : []; } catch(e){ return []; }
  }
  function saveCart(){ try { sessionStorage.setItem("ph.cart", JSON.stringify(state.cart)); } catch(e){} }
  var STEP_LABELS = ["Browse", "Cart", "Account", "Fulfillment", "Payment", "Confirmed"];
  // REVISION 3: realistic estimates, kept in one place so the team can adjust them to the real process.
  var PICKUP_ESTIMATE = "Ready for pickup in about 2 hours at the Ilocos Sur branch";
  var DELIVERY_SHORT = "Same-day delivery, about 2\u20134 hours";
  var DELIVERY_NOTE = "Estimated 2\u20134 hours within Caoayan and nearby Ilocos Sur towns. Orders placed after 5:00 PM are delivered the next morning. Farther areas may take longer.";
  var CURRENCY = "\u20b1";
  /* ---------- server connection ---------- */
  var STATUS_FLOW = ["Pending", "Preparing", "Ready", "Completed"];
  var TOKEN = null;
  try { TOKEN = sessionStorage.getItem("ph.token"); } catch(e){}
  var db = { orders: [], users: [], products: [] }; // admin view of server data, refreshed from the API
  // The backend is PHP (api.php) running under XAMPP's Apache. Requests go to <this folder>/api/... (via .htaccess);
  // if the server has no URL rewriting, they automatically switch to api.php?route=... instead.
  var API_BASE = location.pathname.replace(/[^\/]*$/, "");
  var API_MODE = "pretty";
  function apiUrl(url){
    var r = url.replace(/^\/api\//, "");
    return API_MODE === "query" ? API_BASE + "api.php?route=" + encodeURIComponent(r) : API_BASE + "api/" + r;
  }
  var SERVER_DOWN = "Cannot reach the PetalHub server. In the XAMPP Control Panel make sure Apache and MySQL are running, then open http://localhost/petalhub/ (the folder must be inside xampp\\htdocs).";
  function api(method, url, body, retried){
    var headers = { "Content-Type": "application/json" };
    if (TOKEN){ headers.Authorization = "Bearer " + TOKEN; headers["X-Auth-Token"] = TOKEN; }
    return fetch(apiUrl(url), { method: method, headers: headers, body: body ? JSON.stringify(body) : undefined }).then(function(r){
      return r.json().catch(function(){ return null; }).then(function(j){
        // no JSON back: either URL rewriting is off (try api.php?route=...) or this page is not served by Apache + PHP
        if (j === null){
          if (!retried && API_MODE === "pretty" && [403, 404, 405].indexOf(r.status) >= 0){ API_MODE = "query"; return api(method, url, body, true); }
          throw new Error(SERVER_DOWN);
        }
        if (r.status === 401 && TOKEN && url !== "/api/login") expireSession();
        if (!r.ok) throw new Error(j.error || "Something went wrong.");
        return j;
      });
    }, function(){ throw new Error(SERVER_DOWN); });
  }
  function flowerById(id){ return FLOWERS.filter(function(x){ return x.id === id; })[0]; }
  // Stock always comes from the server (set by the admin): "Out of stock" => 0, otherwise the quantity. null = not loaded yet.
  function stockQty(f){ if (f.available === false) return 0; return typeof f.qty === "number" ? f.qty : null; }
  function loadProducts(){
    return api("GET", "/api/products").then(function(list){
      state.serverError = "";
      var ids = {};
      list.forEach(function(p){
        ids[p.id] = true;
        var f = flowerById(p.id);
        if (!f){ f = { id: p.id, name: p.name, petals: 8, color: "var(--rose)", tag: "New", desc: p.desc || "Fresh flowers from PetalHub.", image: "flowers/placeholder.svg", photoAlt: p.name }; FLOWERS.push(f); }
        f.price = p.price; f.stock = p.stock; f.qty = p.qty; f.available = p.available;
      });
      FLOWERS = FLOWERS.filter(function(f){ return ids[f.id]; });
      state.cart = state.cart.filter(function(l){
        return l.arrangementType === "custom" ?
          Array.isArray(l.flowers) && l.flowers.length && l.flowers.every(function(item){ return ids[item.id]; }) :
          ids[l.id];
      });
      // Re-cap every cart line against refreshed stock, including each flower in a custom bouquet.
      var remaining = {};
      FLOWERS.forEach(function(f){ remaining[f.id] = stockQty(f); });
      state.cart = state.cart.filter(function(line){
        var parts = lineFlowers(line), maxLineQty = 99;
        parts.forEach(function(item){
          var available = remaining[item.id];
          if (available !== null) maxLineQty = Math.min(maxLineQty, Math.floor(available / item.qty));
        });
        if (maxLineQty < 1) return false;
        if (line.qty > maxLineQty) line.qty = maxLineQty;
        parts.forEach(function(item){
          if (remaining[item.id] !== null) remaining[item.id] -= item.qty * line.qty;
        });
        return true;
      });
    });
  }
  function loadAdmin(){
    return Promise.all([api("GET", "/api/admin/orders"), api("GET", "/api/admin/customers"), api("GET", "/api/admin/products")]).then(function(r){ db.orders = r[0]; db.users = r[1]; db.products = r[2]; });
  }
  function applyUser(u){ state.authenticated = true; state.userName = u.name; state.userEmail = u.email; state.isAdmin = u.role === "admin"; }
  function startSession(r){
    TOKEN = r.token; try { sessionStorage.setItem("ph.token", TOKEN); } catch(e){}
    applyUser(r.user);
    return state.isAdmin ? loadAdmin().then(function(){ go("admin"); }) : go(!state.cart.length ? "home" : (state.afterCheckout ? "fulfillment" : "cart"));
  }
  function showErr(e){ alert(e.message); }

  /* ---------- state ---------- */
  var state = {
    screen: "home",
    detailId: null,
    qty: 1,
    arrangementType: "single",
    wrapChoice: "none",
    wrapDesign: WRAPPING_DESIGNS[0].id,
    customFlowers: {},
    customWrapColor: "",
    customWrapNotes: "",
    cart: loadCart(),
    notice: "",
    afterCheckout: false,
    lastOrder: null,
    serverError: "",
    authenticated: false,
    userName: "",
    userEmail: "",
    isAdmin: false,
    adminTab: "orders",
    myOrders: [],
    registerError: "",
    registerForm: { name: "", email: "", pass: "", pass2: "" },
    loginError: "",
    loginForm: { email: "", pass: "" },
    weatherChoice: null,
    fulfillment: null,
    address: { street: "", city: "", zip: "" },
    payment: null,
    orderCode: null,
    checkoutKey: null,
    deliveryError: "",
    placing: false
  };

  // REVISION 1 + 2: screens that only make sense in a certain state are redirected instead of showing stale data.
  var CHECKOUT_SCREENS = ["fulfillment", "delivery", "payment", "confirm"];
  function resolveScreen(screen){
    if (screen === "admin" && !state.isAdmin) return "home";
    if (screen === "orders" && !state.authenticated) return "home";
    if (CHECKOUT_SCREENS.indexOf(screen) >= 0){
      if (!state.cart.length) return "cart";
      if (!state.authenticated) return "authGate";
      if (state.isAdmin) return "home";
      if ((screen === "payment" || screen === "confirm") && !state.fulfillment) return "fulfillment";
      if (screen === "confirm" && !state.payment) return "payment";
    }
    if (screen === "done" && !state.orderCode) return "home";
    if (state.authenticated && ["authGate", "register", "login"].indexOf(screen) >= 0) return "home";
    return screen;
  }
  // REVISION 1: browser Back/Forward buttons now move between app screens instead of leaving the site.
  function go(screen, fromHistory){
    state.screen = resolveScreen(screen);
    if (state.screen !== "cart") state.notice = "";
    if (!fromHistory){ try { history.pushState({ ph: state.screen }, ""); } catch(e){} }
    window.scrollTo(0,0); render();
  }
  window.addEventListener("popstate", function(ev){
    go(ev.state && ev.state.ph ? ev.state.ph : "home", true);
  });
  try { history.replaceState({ ph: "home" }, ""); } catch(e){}
  function expireSession(){
    TOKEN = null; try { sessionStorage.removeItem("ph.token"); } catch(e){}
    state.authenticated = false; state.isAdmin = false; state.userName = ""; state.userEmail = ""; state.myOrders = [];
    state.loginError = "Your session expired. Please log in again.";
    go("login");
  }

  function cartCount(){
    return state.cart.reduce(function(s, l){ return s + l.qty; }, 0);
  }
  function flowerSubtotal(line){
    if (line.arrangementType === "custom") return line.flowers.reduce(function(total, item){
      var flower = flowerById(item.id);
      return total + (flower ? flower.price * item.qty : 0);
    }, 0) * line.qty;
    var flower = flowerById(line.id);
    return flower ? flower.price * line.qty : 0;
  }
  function wrapOption(line){ return WRAPPING_DESIGNS.filter(function(option){ return option.id === line.wrapDesign; })[0]; }
  function wrappingSubtotal(){
    return state.cart.reduce(function(total, line){
      var option = wrapOption(line);
      return total + (line.wrapChoice === "wrapped" && option ? option.price * line.qty : 0);
    }, 0);
  }
  function itemsSubtotal(){ return state.cart.reduce(function(total, line){ return total + flowerSubtotal(line); }, 0); }
  function lineTotal(line){
    var option = wrapOption(line);
    return flowerSubtotal(line) + (line.wrapChoice === "wrapped" && option ? option.price * line.qty : 0);
  }
  function cartTotal(){ return state.cart.reduce(function(total, line){ return total + lineTotal(line); }, 0); }
  function customFlowerSubtotal(){
    return FLOWERS.reduce(function(total, flower){ return total + flower.price * (state.customFlowers[flower.id] || 0); }, 0);
  }
  function customFlowerList(flowers, multiplier){
    return flowers.map(function(item){
      var flower = flowerById(item.id);
      return flower ? '<span class="custom-flower-item">' + esc(flower.name) + ' ×' + (item.qty * multiplier) + '</span>' : "";
    }).join("");
  }
  function customWrapNotes(line){
    var notes = [];
    if (line.wrapColor) notes.push("Requested color: " + esc(line.wrapColor));
    if (line.wrapNotes) notes.push("Notes: " + esc(line.wrapNotes));
    return notes.length ? '<small>' + notes.join(" · ") + '</small>' : "";
  }
  function wrappingColor(option){ return '<small class="wrap-design-color">Color: ' + esc(option.color) + '</small>'; }
  function wrappingImage(option, className){
    return '<img class="' + className + '" src="' + esc(option.image) + '" alt="' + esc(option.name) + ' wrapping preview" loading="lazy">';
  }
  function newLineId(){ return "line-" + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function lineFlowers(line){
    return line.arrangementType === "custom" ? line.flowers : [{ id: line.id, qty: 1 }];
  }
  function stockUsed(id, exceptLine){
    return state.cart.reduce(function(total, line){
      if (line === exceptLine) return total;
      var item = lineFlowers(line).filter(function(flower){ return flower.id === id; })[0];
      return total + (item ? item.qty * line.qty : 0);
    }, 0);
  }
  function canIncreaseLine(line){
    return lineFlowers(line).every(function(item){
      var flower = flowerById(item.id), max = flower ? stockQty(flower) : null;
      return max === null || max - stockUsed(item.id, line) >= item.qty;
    });
  }
  function money(n){ return CURRENCY + n.toFixed(2); }
  function flowerStock(id){ var f = flowerById(id); return f ? stockQty(f) : null; }
  function statusBadge(st){ return '<span class="order-status status-' + esc(String(st).toLowerCase()) + '">' + esc(st) + '</span>'; }
  // small reusable "Back" button used on every screen that needs one
  function backBtn(label, target, w){ return '<button type="button" class="back-link"' + (w ? ' style="display:flex;width:100%;max-width:' + w + 'px;margin:0 auto 14px;justify-content:flex-start;"' : '') + ' onclick="App.go(\'' + target + '\')">' + iconBack() + esc(label) + '</button>'; }
  // Mother's Day is the second Sunday in May and must be recalculated for each year.
  function secondSundayOfMay(year){
    var firstMayDay = new Date(year, 4, 1).getDay();
    return 1 + ((7 - firstMayDay) % 7) + 7;
  }
  // Availability is whatever the admin set on the server (In stock / Out of stock and quantity).
  function hasAvailableStock(flower){ var q = stockQty(flower); return q === null || q > 0; }
  // Use local calendar fields so occasion dates follow the visitor's local date and repeat every year.
  function occasionForDate(date){
    var month = date.getMonth() + 1;
    var day = date.getDate();
    var year = date.getFullYear();
    if (month === 5 && day === secondSundayOfMay(year)){
      return { name: "Mother's Day", message: "Celebrate someone who makes life bloom.", recommendedFlowerIds: [1, 4, 6] };
    }
    return OCCASIONS.filter(function(occasion){ return occasion.month === month && occasion.day === day; })[0] || null;
  }
  // Build recommendation cards from FLOWERS, retaining their real price, image, and live stock text.
  // Priority: holiday/event occasion (most specific) > simulated weather (if the visitor picked one) >
  // current season (always available) > a generic fallback if the top pick has nothing in stock.
  function screenRecommendations(){
    var occasion = occasionForDate(new Date());
    var weather = state.weatherChoice ? WEATHER_PRESETS.filter(function(w){ return w.id === state.weatherChoice; })[0] : null;
    var season = currentSeason(new Date());

    var source = occasion || weather || season;
    var reasonLabel = occasion ? occasion.name : (weather ? weather.label + " weather" : season.name);
    var heading = occasion ? occasion.name + " Picks" : (weather ? weather.label + " Day Picks" : season.name + " Picks");
    var message = source.message;

    var candidates = source.recommendedFlowerIds.map(function(id){
      return FLOWERS.filter(function(flower){ return flower.id === id; })[0];
    });
    var available = candidates.filter(function(flower){ return flower && hasAvailableStock(flower); });

    var usedFallback = false;
    if (available.length === 0){
      available = FLOWERS.filter(function(flower){ return hasAvailableStock(flower); }).slice(0, 3);
      usedFallback = true;
    }

    var cards = available.map(function(flower){
      return '' +
        '<button class="recommendation-card" onclick="App.openDetail(' + flower.id + ')">' +
          '<span class="recommendation-photo">' + flowerPhoto(flower, "recommendation-image", true, false) + '</span>' +
          '<span class="recommendation-info"><span class="recommendation-name">' + esc(flower.name) + '</span>' +
            '<span class="recommendation-price">' + money(flower.price) + ' / bunch</span>' +
            '<span class="recommendation-stock">' + esc(flower.stock) + '</span>' +
            '<span class="recommendation-reason">' + (usedFallback ? "Fresh pick today" : "Recommended for " + esc(reasonLabel)) + '</span></span>' +
        '</button>';
    }).join("");
    var emptyMessage = available.length === 0 ? '<p class="recommendation-empty">No flowers are currently available. Please check back soon.</p>' : '';

    var weatherToggle = '<div class="weather-toggle" role="group" aria-label="Simulate today\u2019s weather">' +
      '<span class="weather-toggle-label">Simulate weather:</span>' +
      WEATHER_PRESETS.map(function(w){
        var sel = state.weatherChoice === w.id;
        return '<button class="weather-chip' + (sel ? ' selected' : '') + '" onclick="App.setWeather(\'' + w.id + '\')">' + esc(w.label) + '</button>';
      }).join("") +
      (state.weatherChoice ? '<button class="weather-chip weather-chip-clear" onclick="App.setWeather(null)">Clear</button>' : '') +
      '</div>';

    return '<section class="recommendations" aria-labelledby="recommendation-heading">' +
      '<div class="recommendations-heading"><div><p class="eyebrow">Selected for the moment</p><h2 id="recommendation-heading">' + esc(heading) + '</h2><p>' + esc(message) + '</p></div></div>' +
      (occasion ? '' : weatherToggle) +
      (cards ? '<div class="recommendation-grid">' + cards + '</div>' : emptyMessage) +
      '</section>';
  }
  function esc(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c];
    });
  }

  /* ---------- icons ---------- */
  function flowerPhoto(flower, className, decorative, eager){
    return '<img class="' + className + '" src="' + esc(flower.image) + '" alt="' + (decorative ? '' : esc(flower.photoAlt)) + '" loading="' + (eager ? 'eager' : 'lazy') + '" decoding="async" onerror="this.onerror=null;this.src=\'flowers/placeholder.svg\'">';
  }
  function iconCart(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.4" fill="currentColor" stroke="none"/><circle cx="18" cy="20" r="1.4" fill="currentColor" stroke="none"/><path d="M2.5 3h2l2.2 12.2a2 2 0 0 0 2 1.6h8.6a2 2 0 0 0 2-1.6L21 7H6"/></svg>';
  }
  function iconBack(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>';
  }
  function iconStore(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l1.5-5h15L21 9"/><path d="M3 9h18v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9z"/><path d="M9 20v-6h6v6"/></svg>';
  }
  function iconTruck(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="1.5" y="7" width="13" height="9"/><path d="M14.5 10h4l3.5 3.5V16h-7.5z"/><circle cx="6" cy="18.5" r="1.6"/><circle cx="17.5" cy="18.5" r="1.6"/></svg>';
  }
  function iconCard(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/></svg>';
  }
  function iconWallet(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7a2 2 0 0 1 2-2h13a1 1 0 0 1 1 1v3"/><path d="M3 7v11a2 2 0 0 0 2 2h14a1 1 0 0 0 1-1v-5a1 1 0 0 0-1-1h-4a2.5 2.5 0 0 1 0-5h4"/></svg>';
  }
  function iconCash(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="6" width="20" height="12" rx="1.5"/><circle cx="12" cy="12" r="3"/></svg>';
  }
  function iconCheck(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="var(--sage)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10" fill="rgba(124,152,133,0.12)"/><path d="M8 12.5l2.6 2.6L16 9.5"/></svg>';
  }
  function iconEmptyCart(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.2" fill="currentColor" stroke="none"/><circle cx="18" cy="20" r="1.2" fill="currentColor" stroke="none"/><path d="M2.5 3h2l2.2 12.2a2 2 0 0 0 2 1.6h8.6a2 2 0 0 0 2-1.6L21 7H6"/></svg>';
  }
  function brandMark(){
    return '<svg class="brand-mark" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">' +
      '<g>' + petalFlowerMini() + '</g></svg>';
  }
  function petalFlowerMini(){
    var cx=12, cy=12, r=8.4, s="";
    for (var i=0;i<6;i++){
      var a = i*60;
      s += '<ellipse cx="'+cx+'" cy="'+(cy-r*0.55)+'" rx="'+(r*0.30)+'" ry="'+(r*0.58)+'" fill="var(--rose-deep)" transform="rotate('+a+' '+cx+' '+cy+')"/>';
    }
    s += '<circle cx="'+cx+'" cy="'+cy+'" r="'+(r*0.24)+'" fill="var(--gold)"/>';
    return s;
  }

  /* ---------- chrome ---------- */
  function stepIndexFor(screen){
    switch(screen){
      case "home": return 0;
      case "detail": return 0;
      case "cart": return 1;
      case "authGate": case "register": case "login": return 2;
      case "fulfillment": case "delivery": return 3;
      case "payment": return 4;
      case "confirm": case "done": return 5;
      default: return 0;
    }
  }
  function renderSteps(){
    var current = stepIndexFor(state.screen);
    var html = '<div class="steps">';
    STEP_LABELS.forEach(function(label, i){
      var cls = "step" + (i === current ? " active" : (i < current ? " done" : ""));
      html += '<div class="' + cls + '"><div class="step-bar"></div><div class="step-label">' + esc(label) + '</div></div>';
    });
    html += '</div>';
    return html;
  }
  function renderTopbar(){
    var count = cartCount();
    var cartClickable = !state.isAdmin || count > 0;
    return '' +
      '<div class="topbar">' +
        '<div class="topbar-inner">' +
          '<button class="brand" onclick="App.go(\'home\')">' + brandMark() + 'PetalHub</button>' +
          '<div class="account-controls">' +
            (state.isAdmin ? '<button class="logout-btn" onclick="App.openAdmin()">Admin</button>' : '') + (state.authenticated ? '<span class="account-name">' + esc(state.userName) + '</span><button class="logout-btn" onclick="App.logout()">Log out</button>' : '<button class="logout-btn" onclick="App.go(\'login\')">Log in</button>') +
            '<button class="cart-pill" ' + (cartClickable ? 'onclick="App.openCart()"' : 'style="opacity:.55;cursor:default"') + '>' +
              iconCart() + '<span>Cart</span><span class="cart-count">' + count + '</span>' +
            '</button>' +
          '</div>' +
        '</div>' +
        (["home", "admin", "orders"].indexOf(state.screen) >= 0 ? "" : renderSteps()) +
      '</div>';
  }

  /* ---------- screens ---------- */
  function heroFlower(i){ return FLOWERS.length ? FLOWERS[i % FLOWERS.length] : { image: "flowers/placeholder.svg", photoAlt: "" }; }
  // One entry per cart line that was ordered. The server stores one row per flower, so rows that share a line_key are grouped back together.
  var ARRANGEMENT_LABELS = { single: "Single Flower", bouquet: "Ready-Made Bouquet", custom: "Custom Bouquet" };
  function orderLines(o){
    var groups = [], byKey = {};
    (o.items || []).forEach(function(it, i){
      var key = it.lineKey || ("row-" + i), g = byKey[key];
      if (!g){
        g = byKey[key] = { arrangement: ARRANGEMENT_LABELS[it.arrangement] ? it.arrangement : "single", lineQty: it.lineQty > 0 ? it.lineQty : 1,
          wrapDesign: it.wrapDesign || "", wrapColor: it.wrapColor || "", wrapNotes: it.wrapNotes || "", wrapFee: 0, flowers: [], total: 0 };
        groups.push(g);
      }
      g.wrapFee += it.wrapFee || 0;
      g.total += it.price * it.qty;
      g.flowers.push({ name: it.name, qty: it.qty });
    });
    return groups;
  }
  function orderLinesHtml(o){
    return '<div class="order-lines">' + orderLines(o).map(function(g){
      var custom = g.arrangement === "custom";
      var count = custom ? g.lineQty : g.flowers[0].qty;
      var title = custom ? "Custom Bouquet" : g.flowers[0].name;
      var flowers = custom ? '<ul class="order-line-flowers">' + g.flowers.map(function(f){
        return '<li>' + esc(f.name) + ' \u00d7 ' + (f.qty / g.lineQty) + '</li>';
      }).join("") + '</ul>' + (g.lineQty > 1 ? '<small class="order-line-note">Flowers listed are for one bouquet; ordered \u00d7 ' + g.lineQty + '.</small>' : '') : '';
      var wrap = "";
      if (g.arrangement !== "single"){
        var option = WRAPPING_DESIGNS.filter(function(d){ return d.id === g.wrapDesign; })[0];
        if (g.wrapDesign){
          wrap = '<div class="order-line-wrap"><span class="order-line-label">Wrapping</span><span><strong>' + esc(option ? option.name : g.wrapDesign) + '</strong>' +
            (option ? ' \u00b7 ' + esc(option.color) : '') + (g.wrapFee > 0 ? ' \u00b7 +' + money(g.wrapFee) : '') +
            (g.wrapColor ? '<small>Requested color: ' + esc(g.wrapColor) + '</small>' : '') +
            (g.wrapNotes ? '<small>Notes: ' + esc(g.wrapNotes) + '</small>' : '') + '</span></div>';
        } else wrap = '<div class="order-line-wrap"><span class="order-line-label">Wrapping</span><span>Without wrapping</span></div>';
      }
      return '<div class="order-line"><div class="order-line-head"><span><span class="type-badge type-' + g.arrangement + '">' + esc(ARRANGEMENT_LABELS[g.arrangement]) + '</span> ' +
        '<strong>' + esc(title) + '</strong> \u00d7 ' + count + '</span><span class="order-line-total">' + money(g.total + g.wrapFee) + '</span></div>' + flowers + wrap + '</div>';
    }).join("") + '</div>';
  }
  function screenOrders(){
    var list = state.myOrders || [];
    var body = list.length ? list.map(function(o){
      return '<div class="admin-card"><div class="row"><strong>' + esc(o.code) + '</strong>' + statusBadge(o.status) + '</div><p class="sub" style="margin-bottom:6px">' + esc(new Date(o.date).toLocaleString()) + '</p>' +
        orderLinesHtml(o) + '<div class="order-total"><span>Total</span><strong>' + money(o.total) + '</strong></div><p class="sub" style="margin-bottom:0">' + (o.fulfillment === "delivery" ? "Delivery to " + esc([o.address.street, o.address.city, o.address.zip].filter(Boolean).join(", ")) : "Pickup at store") + ' \u00b7 ' + esc(o.payment) + '</p></div>';
    }).join("") : '<p class="sub">You have no orders yet.</p>';
    return backBtn("Back to browse", "home") + '<div class="panel"><h2>My orders</h2><p class="sub">Orders you have already placed. These are separate from your cart, so you will not be charged twice.</p>' + body +
      '<div class="admin-actions"><button class="btn" onclick="App.go(\'home\')">Back to Browse</button><button class="btn secondary" onclick="App.go(\'cart\')">Go to cart (' + cartCount() + ')</button></div></div>';
  }
  function screenHome(){
    var cards = FLOWERS.map(function(f){
      var soldOut = stockQty(f) === 0;
      return '' +
        '<button class="flower-card' + (soldOut ? ' sold-out' : '') + '" onclick="App.openDetail(' + f.id + ')">' +
          '<span class="flower-tag">' + esc(f.tag) + '</span>' +
          '<div class="flower-photo-wrap">' + flowerPhoto(f, "flower-photo", false, false) + '</div>' +
          '<div class="flower-name display">' + esc(f.name) + '</div>' +
          '<div class="flower-price">' + money(f.price) + ' / bunch</div>' +
          (soldOut ? '<div class="flower-soldout">Out of stock</div>' : '') +
        '</button>';
    }).join("");
    return '' +
      '<section class="hero">' +
        '<div class="hero-copy"><div class="eyebrow">The PetalHub growers’ room</div><h1>Fresh stems, chosen and sent with care.</h1><p>Browse this week\u2019s cuts from our growers\u2019 room, add what catches your eye, and we\u2019ll get it to you \u2014 by pickup or delivery.</p><button class="btn hero-cta" onclick="App.browseCollection()">Explore the collection</button><div class="hero-note">Freshly gathered, arranged for your everyday</div></div>' +
        '<div class="bouquet-scene" aria-label="A floating arrangement of real garden flowers" role="img"><div class="bouquet-glow"></div><div class="bouquet-platform"></div><div class="bouquet">' +
          '<div class="bouquet-bloom bouquet-bloom-a">' + flowerPhoto(heroFlower(0), "bouquet-photo", true, true) + '</div>' +
          '<div class="bouquet-bloom bouquet-bloom-b">' + flowerPhoto(heroFlower(3), "bouquet-photo", true, true) + '</div>' +
          '<div class="bouquet-bloom bouquet-bloom-c">' + flowerPhoto(heroFlower(2), "bouquet-photo", true, true) + '</div>' +
          '<div class="bouquet-bloom bouquet-bloom-d">' + flowerPhoto(heroFlower(1), "bouquet-photo", true, true) + '</div>' +
          '<div class="bouquet-bloom bouquet-bloom-e">' + flowerPhoto(heroFlower(4), "bouquet-photo", true, true) + '</div>' +
          '<div class="bouquet-bloom bouquet-bloom-f">' + flowerPhoto(heroFlower(5), "bouquet-photo", true, true) + '</div>' +
        '</div><div class="bouquet-caption">A little color, gathered fresh</div></div>' +
      '</section>' +
      screenRecommendations() +
      '<div class="collection-head" id="flower-collection"><div><h2>Flowers in season</h2><p>Gathered from this week’s grower selections</p></div></div>' +
      '<div class="grid">' + cards + '</div>';
  }

  // how many more of this flower can still be added (stock minus what is already in the cart)
  function room(f){ var max = stockQty(f); return max === null ? 99 : Math.max(0, max - stockUsed(f.id)); }
  function screenDetail(){
    var f = FLOWERS.filter(function(x){ return x.id === state.detailId; })[0];
    if (!f) { state.screen = "home"; return screenHome(); }
    var isReadyBouquet = state.arrangementType === "bouquet";
    var isCustomBouquet = state.arrangementType === "custom";
    var selectedStemCount = FLOWERS.reduce(function(total, flower){ return total + (state.customFlowers[flower.id] || 0); }, 0);
    var wrap = wrapOption({ wrapDesign: state.wrapDesign });
    var designs = WRAPPING_DESIGNS.map(function(option){
      var selected = state.wrapDesign === option.id;
      return '<button type="button" class="wrap-style' + (selected ? ' selected' : '') + '" aria-pressed="' + selected + '" onclick="App.chooseWrapDesign(\'' + option.id + '\')">' +
        wrappingImage(option, "wrap-style-image") + '<span class="wrap-style-name">' + esc(option.name) + '</span><span class="wrap-style-price">+' + money(option.price) + '</span>' + wrappingColor(option) + '<span class="wrap-style-detail">' + esc(option.detail) + '</span></button>';
    }).join("");
    var customFlowerRows = FLOWERS.map(function(flower){
      var qty = state.customFlowers[flower.id] || 0;
      var available = room(flower);
      var limit = available === null ? 99 : available;
      return '<div class="builder-flower-row">' +
        '<div class="builder-flower-info"><strong>' + esc(flower.name) + '</strong><small>' + money(flower.price) + ' each · ' + esc(flower.stock) + '</small></div>' +
        '<div class="builder-qty"><button type="button" class="qty-btn" aria-label="Remove one ' + esc(flower.name) + '" onclick="App.changeCustomFlower(' + flower.id + ',-1)"' + (qty < 1 ? ' disabled' : '') + '>−</button><span class="qty-val">' + qty + '</span><button type="button" class="qty-btn" aria-label="Add one ' + esc(flower.name) + '" onclick="App.changeCustomFlower(' + flower.id + ',1)"' + (qty >= limit ? ' disabled title="No more stock available"' : '') + '>+</button></div>' +
        '<strong class="builder-line-total">' + money(flower.price * qty) + '</strong>' +
      '</div>';
    }).join("");
    var detailTotal = isCustomBouquet ? customFlowerSubtotal() + (state.wrapChoice === "wrapped" && wrap ? wrap.price : 0) :
      (f.price + (isReadyBouquet && state.wrapChoice === "wrapped" && wrap ? wrap.price : 0)) * state.qty;
    return '' +
      '<button class="back-link" onclick="App.go(\'home\')">' + iconBack() + 'Back to browsing</button>' +
      '<div class="detail">' +
        '<div class="detail-visual detail-visual-' + f.id + '">' + flowerPhoto(f, "detail-photo", false, true) + '</div>' +
        '<div class="detail-body">' +
          '<span class="flower-tag">' + esc(f.tag) + '</span>' +
          '<h2 style="margin-top:10px;">' + esc(f.name) + '</h2>' +
          '<div class="detail-price">' + money(f.price) + ' base price per bunch</div>' +
          '<p class="detail-desc">' + esc(f.desc) + '</p>' +
          '<div class="detail-stock"><span class="stock-badge' + (stockQty(f) === 0 ? ' out' : '') + '">' + (stockQty(f) === 0 ? 'Out of Stock' : 'In Stock') + '</span>' + (stockQty(f) === 0 ? '' : '<span>' + esc(f.stock) + '</span>') + '</div>' +
          '<section class="product-options" aria-label="Customize your order">' +
            '<fieldset class="option-group"><legend>1. Purchase type</legend><div class="option-choice-row arrangement-choice-row">' +
              '<button type="button" class="option-choice' + (state.arrangementType === "single" ? ' selected' : '') + '" aria-pressed="' + (state.arrangementType === "single") + '" onclick="App.chooseArrangement(\'single\')"><span class="option-choice-title">Single Flower</span><span class="option-choice-detail">Individual stems, unwrapped</span></button>' +
              '<button type="button" class="option-choice' + (isReadyBouquet ? ' selected' : '') + '" aria-pressed="' + isReadyBouquet + '" onclick="App.chooseArrangement(\'bouquet\')"><span class="option-choice-title">Ready-Made Bouquet</span><span class="option-choice-detail">This flower arranged as a bouquet</span></button>' +
              '<button type="button" class="option-choice' + (isCustomBouquet ? ' selected' : '') + '" aria-pressed="' + isCustomBouquet + '" onclick="App.chooseArrangement(\'custom\')"><span class="option-choice-title">Custom Bouquet</span><span class="option-choice-detail">Build your bouquet from any flowers</span></button>' +
            '</div></fieldset>' +
            (isCustomBouquet ? '<section class="custom-builder" aria-labelledby="custom-builder-title"><h3 id="custom-builder-title">2. Build your bouquet</h3><p class="builder-hint">Choose the flowers and quantities for your arrangement.</p><div class="builder-flower-list">' + customFlowerRows + '</div><div class="builder-subtotal"><span>Flowers (' + selectedStemCount + ' stems)</span><strong>' + money(customFlowerSubtotal()) + '</strong></div></section>' : '') +
            (isReadyBouquet || (isCustomBouquet && selectedStemCount > 0) ? '<fieldset class="option-group"><legend>2. Wrapping preference</legend><div class="option-choice-row">' +
              '<button type="button" class="option-choice' + (state.wrapChoice === "wrapped" ? ' selected' : '') + '" aria-pressed="' + (state.wrapChoice === "wrapped") + '" onclick="App.chooseWrapType(\'wrapped\')"><span class="option-choice-title">With Wrapping</span><span class="option-choice-detail">Choose a wrapping design</span></button>' +
              '<button type="button" class="option-choice' + (state.wrapChoice === "none" ? ' selected' : '') + '" aria-pressed="' + (state.wrapChoice === "none") + '" onclick="App.chooseWrapType(\'none\')"><span class="option-choice-title">Without Wrapping</span><span class="option-choice-detail">No additional charge</span></button>' +
            '</div></fieldset>' : '') +
            ((isReadyBouquet || isCustomBouquet) && state.wrapChoice === "wrapped" && (!isCustomBouquet || selectedStemCount > 0) ? '<fieldset class="option-group"><legend>3. Wrapping design</legend><div class="wrap-styles" role="group" aria-label="Wrapping designs">' + designs + '</div>' +
              (isCustomBouquet ? '<div class="custom-wrap-fields"><div class="field"><label for="custom-wrap-color">Wrapping color preference</label><input id="custom-wrap-color" type="text" value="' + esc(state.customWrapColor) + '" placeholder="e.g. soft blush pink" onchange="App.updateCustomWrap(\'color\',this.value)"></div><div class="field"><label for="custom-wrap-notes">Material or wrapping notes</label><textarea id="custom-wrap-notes" rows="2" placeholder="Any special material or finishing requests" onchange="App.updateCustomWrap(\'notes\',this.value)">' + esc(state.customWrapNotes) + '</textarea></div></div>' : '') +
            '</fieldset>' : '') +
          '</section>' +
          (!isCustomBouquet ? '<div class="qty-row"><button class="qty-btn" onclick="App.changeQty(-1)" aria-label="Decrease quantity">\u2212</button><span class="qty-val">' + state.qty + '</span><button class="qty-btn" onclick="App.changeQty(1)" aria-label="Increase quantity"' + (state.qty >= room(f) ? ' disabled' : '') + '>+</button></div>' : '') +
          '<div class="detail-total"><span>' + (isCustomBouquet ? 'Custom bouquet total' : 'Total for ' + state.qty) + '</span><strong>' + money(detailTotal) + '</strong></div>' +
          (state.isAdmin ? '<p class="sub">Admin accounts manage the shop and cannot place orders.</p>' :
            (isCustomBouquet ? '<button class="btn" ' + (selectedStemCount === 0 ? 'disabled' : '') + ' onclick="App.addCustomBouquet()">Add custom bouquet to cart</button>' :
              (stockQty(f) === 0 ? '<button class="btn" disabled>Out of stock</button>' : room(f) <= 0 ? '<button class="btn" disabled>All available stock is already in your cart</button>' :
                '<button class="btn" onclick="App.addToCart(' + f.id + ')">Add ' + state.qty + ' to cart — ' + money(detailTotal) + '</button>'))) +
        '</div>' +
      '</div>';
  }

  function screenAuthGate(){
    return '' +
      backBtn("Back to cart", "cart", 460) +
      '<div class="panel" style="max-width:460px;margin:0 auto;">' +
        '<h2>Have a PetalHub account?</h2>' +
        '<p class="sub">Sign in or create an account so we can confirm your order and track delivery.</p>' +
        '<div class="choice-row" style="margin-top:6px;">' +
          '<button class="tap-card" onclick="App.go(\'login\')"><span class="t">Yes, log in</span><span class="d">I already have an account</span></button>' +
          '<button class="tap-card" onclick="App.go(\'register\')"><span class="t">No, register</span><span class="d">Set up a new account</span></button>' +
        '</div>' +
      '</div>';
  }

  function screenRegister(){
    var f = state.registerForm;
    return '' +
      backBtn("Back to log in", "login", 460) +
      '<div class="panel" style="max-width:460px;margin:0 auto;">' +
        '<h2>Register a new account</h2>' +
        '<p class="sub">Takes under a minute to get started.</p>' +
        (state.registerError ? '<div class="error-box" style="margin-bottom:14px;">' + esc(state.registerError) + '</div>' : '') +
        '<form class="stack" onsubmit="return App.submitRegister(event)">' +
          '<div class="field"><label for="reg-name">Full name</label><input id="reg-name" type="text" value="' + esc(f.name) + '" placeholder="Jamie Flores" autocomplete="name"></div>' +
          '<div class="field"><label for="reg-email">Email address</label><input id="reg-email" type="email" value="' + esc(f.email) + '" placeholder="jamie@email.com" autocomplete="email"></div>' +
          '<div class="row2">' +
            '<div class="field"><label for="reg-pass">Password</label><input id="reg-pass" type="password" value="' + esc(f.pass) + '" placeholder="At least 6 characters" autocomplete="new-password"></div>' +
            '<div class="field"><label for="reg-pass2">Confirm password</label><input id="reg-pass2" type="password" value="' + esc(f.pass2) + '" placeholder="Repeat password" autocomplete="new-password"></div>' +
          '</div>' +
          '<button class="btn block" type="submit">Create account</button>' +
        '</form>' +
        '<div class="switch-mode">Already registered? <button onclick="App.go(\'login\')">Log in instead</button></div>' +
      '</div>';
  }

  function screenLogin(){
    var f = state.loginForm;
    return '' +
      backBtn(state.cart.length ? "Back to cart" : "Back to browsing", state.cart.length ? "cart" : "home", 460) +
      '<div class="panel" style="max-width:460px;margin:0 auto;">' +
        '<h2>Log in</h2>' +
        '<p class="sub">Welcome back \u2014 log in to continue. Shop admins can log in here too with their admin email.</p>' +
        (state.loginError ? '<div class="error-box" style="margin-bottom:14px;">' + esc(state.loginError) + '</div>' : '') +
        '<form class="stack" onsubmit="return App.submitLogin(event)">' +
          '<div class="field"><label for="log-email">Email address</label><input id="log-email" type="email" value="' + esc(f.email) + '" placeholder="jamie@email.com" autocomplete="email"></div>' +
          '<div class="field"><label for="log-pass">Password</label><input id="log-pass" type="password" value="' + esc(f.pass) + '" placeholder="Enter your password" autocomplete="current-password"></div>' +
          '<button class="btn block" type="submit">Log in</button>' +
        '</form>' +
        '<div class="switch-mode">New here? <button onclick="App.go(\'register\')">Register an account</button></div>' +
      '</div>';
  }

  function screenCart(){
    // REVISION 2: the cart only ever holds items that have NOT been ordered yet. Placed orders live in "My orders".
    var ordersBtn = state.authenticated && !state.isAdmin ? '<button class="btn secondary" onclick="App.openOrders()">View My Orders</button>' : '';
    if (state.cart.length === 0){
      return (state.notice ? '<div class="error-box" style="margin-bottom:14px;">' + esc(state.notice) + '</div>' : '') + '<div class="empty-state">' + iconEmptyCart() + '<div><strong>Your cart is empty.</strong></div>' +
        '<p class="sub" style="margin-top:8px">' + (state.orderCode ? "Your last order was placed successfully. " : "") + (state.authenticated ? "Orders you have already placed are kept in My Orders." : "Add some flowers to get started.") + '</p>' +
        '<div class="actions-row" style="margin-top:18px;"><button class="btn" onclick="App.go(\'home\')">Back to Browse</button>' + ordersBtn + '</div></div>';
    }
    var lines = state.cart.map(function(l, index){
      var f = flowerById(l.id);
      var firstFlower = f || (l.flowers && flowerById(l.flowers[0].id));
      var wrap = wrapOption(l);
      var lineName = l.arrangementType === "custom" ? "Custom Bouquet" : (f ? f.name : "Flower");
      var arrangement = l.arrangementType === "custom" ? "Custom Bouquet" : (l.arrangementType === "bouquet" ? "Ready-Made Bouquet" : "Single Flower");
      var wrapDetails = l.wrapChoice === "wrapped" && wrap ?
        '<div class="cart-line-wrap">' + wrappingImage(wrap, "cart-wrap-image") + '<span><strong>' + esc(wrap.name) + '</strong>' + wrappingColor(wrap) + '<small>' + esc(wrap.detail) + '</small><small>+' + money(wrap.price) + ' / bouquet</small>' + (l.arrangementType === "custom" ? customWrapNotes(l) : '') + '</span></div>' :
        (l.arrangementType !== "single" ? '<div class="cart-line-wrap">Without wrapping</div>' : '');
      return '' +
        '<div class="cart-line">' +
          '<div class="cart-line-icon">' + (firstFlower ? flowerPhoto(firstFlower, "flower-cart-image", false, false) : '') + '</div>' +
          '<div class="cart-line-info"><div class="cart-line-name">' + esc(lineName) + '</div><div class="cart-line-sub">' + esc(arrangement) + ' · ' + (l.arrangementType === "custom" ? 'Flowers ' + money(flowerSubtotal(l) / l.qty) + ' / bouquet' : money(f ? f.price : 0) + ' base / bunch') + '</div>' +
            (l.arrangementType === "custom" ? '<div class="custom-flower-list">' + customFlowerList(l.flowers, l.qty) + '</div>' : '') +
            wrapDetails + '<button type="button" class="link-btn" onclick="App.removeLine(' + index + ')">Remove</button></div>' +
          '<div class="cart-line-controls">' +
            '<button class="qty-btn" onclick="App.lineQty(' + index + ',-1)" aria-label="Decrease">\u2212</button>' +
            '<span class="qty-val">' + l.qty + '</span>' +
            '<button class="qty-btn" onclick="App.lineQty(' + index + ',1)" aria-label="Increase"' + (canIncreaseLine(l) ? '' : ' disabled title="No more stock available"') + '>+</button>' +
          '</div>' +
          '<div class="cart-line-total">' + money(lineTotal(l)) + '</div>' +
        '</div>';
    }).join("");
    var total = cartTotal();
    return '' +
      (state.notice ? '<div class="error-box" style="margin-bottom:14px;">' + esc(state.notice) + '</div>' : '') +
      '<div class="panel">' +
        '<h2>Your cart</h2>' +
        '<p class="sub">' + (state.authenticated ? "Signed in as " + esc(state.userName) + ". " : "You will be asked to log in or register when you check out. ") + 'These items have not been ordered yet. Orders you already placed are in My Orders.</p>' +
        lines +
        '<div class="summary-row"><span>Flowers</span><span>' + money(itemsSubtotal()) + '</span></div>' +
        '<div class="summary-row"><span>Wrapping</span><span>' + money(wrappingSubtotal()) + '</span></div>' +
        '<div class="summary-row total"><span>Total</span><span>' + money(total) + '</span></div>' +
      '</div>' +
      '<div style="display:flex;gap:12px;margin-top:16px;flex-wrap:wrap;">' +
        '<button class="btn secondary" onclick="App.go(\'home\')">Back to Browse</button>' +
        ordersBtn +
        '<button class="btn" onclick="App.proceed()">Proceed to checkout</button>' +
      '</div>';
  }

  function screenFulfillment(){
    return '' +
      backBtn("Back to cart", "cart", 520) +
      '<div class="panel" style="max-width:520px;margin:0 auto;">' +
        '<h2>Pickup or delivery?</h2>' +
        '<p class="sub">Choose how you\u2019d like to receive your order.</p>' +
        '<div class="choice-row">' +
          '<button class="tap-card" onclick="App.choosePickup()">' + iconStore() + '<span class="t">Pick up at store</span><span class="d">' + esc(PICKUP_ESTIMATE) + '</span></button>' +
          '<button class="tap-card" onclick="App.go(\'delivery\')">' + iconTruck() + '<span class="t">Delivery</span><span class="d">' + esc(DELIVERY_SHORT) + '</span></button>' +
        '</div>' +
      '</div>';
  }

  function screenDelivery(){
    var a = state.address;
    return '' +
      '<div class="panel" style="max-width:520px;margin:0 auto;">' +
        '<button type="button" class="back-link" onclick="App.go(\'fulfillment\')">' + iconBack() + 'Change fulfillment</button>' +
        '<h2>Delivery address</h2>' +
        '<p class="sub">Where should we send your flowers? ' + esc(DELIVERY_NOTE) + '</p>' +
        (state.deliveryError ? '<div class="error-box" style="margin-bottom:14px;">' + esc(state.deliveryError) + '</div>' : '') +
        '<form class="stack" onsubmit="return App.submitDelivery(event)">' +
          '<div class="field"><label for="d-street">Street address</label><input id="d-street" type="text" value="' + esc(a.street) + '" placeholder="123 Rizal Street"></div>' +
          '<div class="row2">' +
            '<div class="field"><label for="d-city">City / town</label><input id="d-city" type="text" value="' + esc(a.city) + '" placeholder="Caoayan"></div>' +
            '<div class="field"><label for="d-zip">ZIP / postal code</label><input id="d-zip" type="text" value="' + esc(a.zip) + '" placeholder="2703"></div>' +
          '</div>' +
          '<button class="btn block" type="submit">Continue to payment</button>' +
        '</form>' +
      '</div>';
  }

  function screenPayment(){
    var opts = [
      { id: "card", label: "Credit / debit card", desc: "Visa, Mastercard", icon: iconCard() },
      { id: "wallet", label: "GCash / e-wallet", desc: "Pay from your mobile wallet", icon: iconWallet() },
      { id: "cash", label: state.fulfillment === "delivery" ? "Cash on delivery" : "Cash on pickup", desc: "Pay when you receive your order", icon: iconCash() }
    ];
    var rows = opts.map(function(o){
      var sel = state.payment === o.id;
      return '<button class="pay-opt' + (sel ? ' selected' : '') + '" onclick="App.choosePayment(\'' + o.id + '\')">' +
        o.icon + '<div><div class="t">' + esc(o.label) + '</div><div class="d">' + esc(o.desc) + '</div></div></button>';
    }).join("");
    return '' +
      backBtn(state.fulfillment === "delivery" ? "Back to delivery address" : "Back to fulfillment", state.fulfillment === "delivery" ? "delivery" : "fulfillment", 520) +
      '<div class="panel" style="max-width:520px;margin:0 auto;">' +
        '<h2>Choose payment method</h2>' +
        '<p class="sub">Fulfillment: ' + (state.fulfillment === "delivery" ? "Delivery to " + esc(state.address.street || "your address") : "Pickup at store") + '</p>' +
        '<div class="payment-list">' + rows + '</div>' +
        '<button class="btn block" ' + (state.payment ? '' : 'disabled') + ' onclick="App.go(\'confirm\')">Review order</button>' +
      '</div>';
  }

  function screenConfirm(){
    var total = cartTotal(), delivery = state.fulfillment === "delivery";
    var payLabel = { card: "Credit / debit card", wallet: "GCash / e-wallet", cash: delivery ? "Cash on delivery" : "Cash on pickup" }[state.payment] || "\u2014";
    var lines = state.cart.map(function(l){
      var f = flowerById(l.id), wrap = wrapOption(l);
      var name = l.arrangementType === "custom" ? "Custom Bouquet" : (f ? f.name : "Flower");
      var arrangement = l.arrangementType === "custom" ? "Custom Bouquet" : (l.arrangementType === "bouquet" ? "Ready-Made Bouquet" : "Single Flower");
      return '<div class="confirm-item"><span>' + esc(name) + ' \u00d7 ' + l.qty + '<small class="confirm-option">' + esc(arrangement) + (l.arrangementType === "custom" ? ' · ' + customFlowerList(l.flowers, l.qty) : '') + (l.wrapChoice === "wrapped" && wrap ? ' · ' + esc(wrap.name) + (l.arrangementType === "custom" ? ' ' + esc([l.wrapColor, l.wrapNotes].filter(Boolean).join(" · ")) : '') : '') + '</small></span><span>' + money(lineTotal(l)) + '</span></div>';
    }).join("");
    var row = function(label, value, link){ return '<div class="confirm-item"><span class="label">' + label + '</span><span>' + value + (link || "") + '</span></div>'; };
    return '' +
      backBtn("Back to payment", "payment", 520) +
      '<div class="panel" style="max-width:520px;margin:0 auto;">' +
        '<h2>Confirm your order</h2>' +
        '<p class="sub">Double-check everything. Your order is only placed when you press Confirm order.</p>' +
        '<div class="confirm-list">' +
          lines +
          '<div class="summary-row total"><span>Total</span><span>' + money(total) + '</span></div>' +
        '</div>' +
        '<div class="confirm-list" style="margin-top:14px;">' +
          row("Fulfillment", delivery ? "Delivery" : "Pickup at store") +
          (delivery ? row("Address", esc([state.address.street, state.address.city, state.address.zip].filter(Boolean).join(", "))) : "") +
          row("Estimated time", esc(delivery ? DELIVERY_SHORT : PICKUP_ESTIMATE)) +
          row("Payment", esc(payLabel)) +
          row("Account", esc(state.userName || "Guest")) +
        '</div>' +
        '<button class="btn block" style="margin-top:18px;" ' + (state.placing ? 'disabled' : '') + ' onclick="App.confirmOrder()">' + (state.placing ? "Placing order\u2026" : "Confirm order") + '</button>' +
        '<button type="button" class="link-btn" style="display:block;margin:12px auto 0;" onclick="App.go(\'cart\')">Edit cart</button>' +
      '</div>';
  }
  function screenDone(){
    return '' +
      '<div class="done-wrap">' +
        '<div class="done-mark">' + iconCheck() + '</div>' +
        '<h2 style="font-size:26px;">Order confirmed</h2>' +
        '<p style="color:var(--text-soft);max-width:360px;margin:10px auto 0;">A confirmation has been sent for your order. Thank you for choosing PetalHub.</p>' +
        '<div class="order-code">' + esc(state.orderCode) + '</div>' +
        (state.savedOrder ? '<div class="confirm-list" style="max-width:460px;margin:0 auto 14px;text-align:left;">' + orderLinesHtml(state.savedOrder) +
          '<div class="summary-row total"><span>Total</span><span>' + money(state.savedOrder.total) + '</span></div></div>' :
        state.lastOrder ? '<div class="confirm-list" style="max-width:360px;margin:0 auto 14px;text-align:left;">' + state.lastOrder.items.map(function(i){
          return '<div class="confirm-item"><span>' + esc(i.name) + ' \u00d7 ' + i.qty + '</span><span>' + money(i.price * i.qty) + '</span></div>'; }).join("") +
          '<div class="summary-row total"><span>Total</span><span>' + money(state.lastOrder.total) + '</span></div></div>' : '') +
        '<p style="color:var(--text-soft);font-size:13.5px;max-width:420px;margin:0 auto 20px;">' + esc(state.lastFulfillment === "delivery" ? DELIVERY_NOTE : PICKUP_ESTIMATE + ".") + '</p>' +
        '<div class="actions-row">' +
          '<button class="btn" onclick="App.newOrder()">Back to Browse</button>' +
          '<button class="btn secondary" onclick="App.openOrders()">View My Orders</button>' +
        '</div>' +
      '</div>';
  }

  // An order is flagged when another order from the same customer has the same items and total within 30 minutes.
  function dupOf(o){
    if (o.status === "Cancelled") return null;
    var sig = function(x){
      return x.items.map(function(i){
        return [i.name, i.qty, i.lineName || "", i.arrangement || "single", i.wrapDesign || "", i.wrapColor || "", i.wrapNotes || "", i.wrapFee || 0].join(":");
      }).sort().join("|") + "|" + x.total + "|" + x.fulfillment;
    };
    var mine = sig(o);
    var hit = db.orders.filter(function(p){
      return p.code !== o.code && p.status !== "Cancelled" && p.email === o.email && sig(p) === mine &&
        Math.abs(new Date(p.date) - new Date(o.date)) <= 30 * 60000 && (new Date(p.date) < new Date(o.date) || (+new Date(p.date) === +new Date(o.date) && p.code < o.code));
    })[0];
    return hit ? hit.code : null;
  }
  function screenAdmin(){
    var tab = state.adminTab;
    var help = {
      orders: "Review new orders and move each one forward (Pending \u2192 Preparing \u2192 Ready \u2192 Completed), or cancel it \u2014 cancelling returns the stems to stock.",
      products: "Set the price, quantity and In stock / Out of stock status of each flower. Customers see exactly what you set here.",
      customers: "See registered customers and how many orders each has placed."
    }[tab];
    var nav = '<div class="admin-tabs">' + ["orders", "products", "customers"].map(function(t){
      return '<button class="' + (t === tab ? 'btn' : 'logout-btn') + '" onclick="App.setTab(\'' + t + '\')">' + t.charAt(0).toUpperCase() + t.slice(1) + '</button>';
    }).join("") + '</div>';
    var body = "";
    if (tab === "orders"){
      body = db.orders.length ? db.orders.map(function(o){
        var idx = STATUS_FLOW.indexOf(o.status), next = idx >= 0 ? STATUS_FLOW[idx + 1] : null;
        return '<div class="admin-card"><div class="row"><strong>' + esc(o.code) + '</strong><span class="admin-status">' + esc(o.status) + '</span></div>' +
          '<p class="sub">' + esc(new Date(o.date).toLocaleString()) + ' \u2014 ' + esc(o.customer) + ' (' + esc(o.email) + ')</p>' +
          orderLinesHtml(o) + '<div class="order-total"><span>Total</span><strong>' + money(o.total) + '</strong></div>' +
          (dupOf(o) ? '<p class="dup-flag">\u26a0 Possible duplicate of ' + esc(dupOf(o)) + ' (same customer, items and total within 30 minutes). Cancel this one if the customer only ordered once \u2014 stock is returned automatically.</p>' : '') +
          '<p class="sub">' + (o.fulfillment === "delivery" ? "Delivery to " + esc([o.address.street, o.address.city, o.address.zip].filter(Boolean).join(", ")) : "Pickup at store") + ' \u00b7 ' + esc(o.payment) + '</p>' +
          (next ? '<div class="admin-actions"><button class="btn" onclick="App.setStatus(\'' + o.code + '\',\'' + next + '\')">Mark ' + next + '</button><button class="logout-btn" onclick="App.cancelOrder(\'' + o.code + '\')">Cancel order</button></div>' : '') + '</div>';
      }).join("") : '<p class="sub">No orders yet.</p>';
    } else if (tab === "products"){
      body = db.products.map(function(p){
        var f = { id: p.id, name: p.name, price: p.price, qty: p.qty, available: p.available, stock: p.stock }, look = flowerById(p.id);
        var on = stockQty(f) > 0;
        return '<div class="admin-card"><div class="row"><span class="admin-prod">' + (look ? flowerPhoto(look, "admin-thumb", true, false) : '') + '<strong>' + esc(f.name) + '</strong></span><span class="stock-state ' + (on ? 'in' : 'out') + '">' + (on ? 'In stock \u00b7 ' + esc(f.stock) : 'Out of stock') + '</span></div>' +
          '<div class="admin-actions"><label>Price ' + CURRENCY + ' <input id="p-price-' + f.id + '" type="number" min="0" step="0.01" value="' + f.price + '"></label>' +
          '<label>Qty <input id="p-qty-' + f.id + '" type="number" min="0" step="1" value="' + (typeof f.qty === "number" ? f.qty : 0) + '"></label>' +
          '<label>Status <select id="p-avail-' + f.id + '"><option value="1"' + (f.available !== false ? ' selected' : '') + '>In stock</option><option value="0"' + (f.available === false ? ' selected' : '') + '>Out of stock</option></select></label>' +
          '<button class="btn" onclick="App.saveProduct(' + f.id + ')">Save</button><button class="logout-btn" onclick="App.deleteProduct(' + f.id + ')">Delete</button></div>' +
          (f.available !== false && f.qty === 0 ? '<p class="sub" style="margin:8px 0 0">Quantity is 0, so customers see this flower as Out of stock.</p>' : '') + '</div>';
      }).join("");
    } else {
      var cs = db.users.filter(function(u){ return u.role !== "admin"; });
      body = cs.length ? cs.map(function(u, ci){
        var n = db.orders.filter(function(o){ return o.email === u.email; }).length;
        return '<div class="admin-card"><div class="row"><strong>' + esc(u.name) + '</strong><span class="sub">' + n + ' order' + (n === 1 ? '' : 's') + '</span></div><p class="sub">' + esc(u.email) + '</p></div>';
      }).join("") : '<p class="sub">No customers have registered yet.</p>';
    }
    return '<div class="panel"><div class="row" style="margin-bottom:6px"><h2 style="margin:0">Admin</h2><div class="admin-actions" style="margin:0"><button class="logout-btn" onclick="App.go(\'home\')">View storefront</button><button class="logout-btn" onclick="App.logout()">Log out</button></div></div><p class="sub">' + help + '</p>' + nav + body + '</div>';
  }
  function renderMain(){
    switch(state.screen){
      case "home": return screenHome();
      case "detail": return screenDetail();
      case "authGate": return screenAuthGate();
      case "register": return screenRegister();
      case "login": return screenLogin();
      case "cart": return screenCart();
      case "fulfillment": return screenFulfillment();
      case "delivery": return screenDelivery();
      case "payment": return screenPayment();
      case "confirm": return screenConfirm();
      case "done": return screenDone();
      case "admin": return state.isAdmin ? screenAdmin() : screenHome();
      case "orders": return state.authenticated ? screenOrders() : screenHome();
      default: return screenHome();
    }
  }

  function render(){
    state.cart = state.cart.filter(function(l){
      return l.arrangementType === "custom" ?
        Array.isArray(l.flowers) && l.flowers.length && l.flowers.every(function(item){ return flowerById(item.id); }) :
        flowerById(l.id);
    });
    saveCart();
    document.getElementById("app").innerHTML =
      renderTopbar() +
      "<main>" + (state.serverError ? '<div class="error-box" style="margin-bottom:16px;">' + esc(state.serverError) + '</div>' : '') + renderMain() + "</main>" +
      '<footer>PetalHub \u2014 Order flowers online.' +
        '<details class="photo-credits"><summary>Flower photography credits</summary><div class="photo-credit-list">' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:Pink_rose_bloom_of_a_climbing_rose_at_Boreham,_Essex,_England_1.jpg">Garden rose photo by Acabashi</a> · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a></p>' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:Red-tulip-macro_-_West_Virginia_-_ForestWander.jpg">Tulip photo by ForestWander</a> · <a href="https://creativecommons.org/licenses/by-sa/3.0/us/deed.en">CC BY-SA 3.0 US</a></p>' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:Sunflower_close_up_shot.jpg">Sunflower photo by Aerous</a> · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a></p>' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:Pink_Peony_Flower.jpg">Peony photo by Nathanieljoyce</a> · <a href="https://creativecommons.org/publicdomain/zero/1.0/">CC0</a></p>' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:IMG_8431_close_up_for_Purple_Orchid_Flower_photographed_by_Peak_Hora.jpg">Orchid photo by Peak Hora</a> · <a href="https://creativecommons.org/licenses/by-sa/4.0/">CC BY-SA 4.0</a></p>' +
          '<p><a href="https://commons.wikimedia.org/wiki/File:A_flower_of_Madonna_lily,_black_stamen_pollen.jpg">Madonna lily photo by Bobjgalindo</a> · <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a></p>' +
        '</div></details></footer>';
    bindDepthInteractions();
  }

  function bindDepthInteractions(){
    if (!window.matchMedia("(hover: hover) and (pointer: fine)").matches || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    document.querySelectorAll(".flower-card, .detail-visual").forEach(function(surface){
      surface.addEventListener("pointermove", function(event){
        var bounds = surface.getBoundingClientRect();
        var x = (event.clientX - bounds.left) / bounds.width * 2 - 1;
        var y = (event.clientY - bounds.top) / bounds.height * 2 - 1;
        surface.style.setProperty("--tilt-x", (-y * 3).toFixed(2) + "deg");
        surface.style.setProperty("--tilt-y", (x * 4).toFixed(2) + "deg");
      });
      surface.addEventListener("pointerleave", function(){
        surface.style.removeProperty("--tilt-x");
        surface.style.removeProperty("--tilt-y");
      });
    });
    var bouquetScene = document.querySelector(".bouquet-scene");
    if (!bouquetScene) return;
    bouquetScene.addEventListener("pointermove", function(event){
      var bounds = bouquetScene.getBoundingClientRect();
      var x = (event.clientX - bounds.left) / bounds.width * 2 - 1;
      var y = (event.clientY - bounds.top) / bounds.height * 2 - 1;
      bouquetScene.style.transform = "rotateX(" + (-y * 2).toFixed(2) + "deg) rotateY(" + (x * 3).toFixed(2) + "deg)";
    });
    bouquetScene.addEventListener("pointerleave", function(){ bouquetScene.style.removeProperty("transform"); });
  }

  /* ---------- actions ---------- */
  var App = {
    go: go,
    browseCollection: function(){
      var collection = document.getElementById("flower-collection");
      if (collection) collection.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
    },
    openDetail: function(id){
      state.detailId = id; state.qty = 1; state.arrangementType = "single"; state.wrapChoice = "none";
      state.wrapDesign = WRAPPING_DESIGNS[0].id; state.customFlowers = {}; state.customWrapColor = ""; state.customWrapNotes = "";
      go("detail");
    },
    changeQty: function(d){
      var f = flowerById(state.detailId);
      state.qty = Math.max(1, Math.min(state.qty + d, f ? Math.max(1, room(f)) : 99)); render();
    },
    chooseArrangement: function(type){
      if (["single", "bouquet", "custom"].indexOf(type) < 0) return;
      if (state.arrangementType !== type) state.wrapChoice = "none";
      state.arrangementType = type; render();
    },
    changeCustomFlower: function(id, delta){
      var flower = flowerById(id), next = (state.customFlowers[id] || 0) + delta;
      if (!flower || next < 0 || next > room(flower)) return;
      if (next) state.customFlowers[id] = next; else delete state.customFlowers[id];
      render();
    },
    chooseWrapType: function(choice){
      if (choice !== "wrapped" && choice !== "none") return;
      state.wrapChoice = choice; render();
    },
    chooseWrapDesign: function(id){
      if (!WRAPPING_DESIGNS.some(function(option){ return option.id === id; })) return;
      state.wrapDesign = id; render();
    },
    updateCustomWrap: function(field, value){
      if (field === "color") state.customWrapColor = value;
      if (field === "notes") state.customWrapNotes = value;
    },
    addToCart: function(id){
      var f = flowerById(id);
      if (state.isAdmin || !f) return;
      var n = Math.min(state.qty, room(f));
      if (n < 1) return;
      var arrangement = state.arrangementType === "bouquet" ? "bouquet" : "single";
      var wrapChoice = arrangement === "bouquet" ? state.wrapChoice : "none";
      var wrapDesign = wrapChoice === "wrapped" ? state.wrapDesign : null;
      var line = state.cart.filter(function(l){
        return l.id === id && l.arrangementType === arrangement && l.wrapChoice === wrapChoice && l.wrapDesign === wrapDesign;
      })[0];
      if (line) line.qty += n;
      else state.cart.push({ id: id, qty: n, arrangementType: arrangement, wrapChoice: wrapChoice, wrapDesign: wrapDesign, lineId: newLineId() });
      state.checkoutKey = null; // cart changed -> this is a new checkout
      go("cart");
    },
    addCustomBouquet: function(){
      if (state.isAdmin) return;
      var flowers = FLOWERS.filter(function(flower){ return (state.customFlowers[flower.id] || 0) > 0; }).map(function(flower){
        return { id: flower.id, qty: state.customFlowers[flower.id] };
      });
      if (!flowers.length || flowers.some(function(item){ var f = flowerById(item.id); return !f || item.qty > room(f); })) return;
      state.cart.push({
        id: null, qty: 1, arrangementType: "custom", flowers: flowers,
        wrapChoice: state.wrapChoice, wrapDesign: state.wrapChoice === "wrapped" ? state.wrapDesign : null,
        wrapColor: state.wrapChoice === "wrapped" ? state.customWrapColor.trim() : "",
        wrapNotes: state.wrapChoice === "wrapped" ? state.customWrapNotes.trim() : "",
        lineId: newLineId()
      });
      state.checkoutKey = null;
      go("cart");
    },
    // Re-check stock, then continue to checkout (guests are asked to log in or register first and come straight back).
    proceed: function(){
      if (!state.cart.length) return go("cart");
      var before = JSON.stringify(state.cart);
      loadProducts().then(function(){
        if (!state.cart.length || JSON.stringify(state.cart) !== before){
          state.notice = "Some items in your cart were changed because the available stock changed. Please review your cart.";
          return go("cart");
        }
        state.notice = "";
        if (!state.authenticated){ state.afterCheckout = true; return go("authGate"); }
        go("fulfillment");
      }).catch(function(e){
        state.serverError = "";
        state.notice = "Stock could not be verified, so checkout is paused. " + e.message;
        go("cart");
      });
    },
    openCart: function(){
      if (state.isAdmin && !state.cart.length) return;
      go("cart");
    },
    removeLine: function(index){ state.cart.splice(index, 1); state.checkoutKey = null; render(); },
    setWeather: function(id){ state.weatherChoice = id; render(); },
    lineQty: function(index, d){
      var line = state.cart[index];
      if (!line) return;
      if (d > 0 && !canIncreaseLine(line)) return;
      line.qty += d;
      if (line.qty <= 0) state.cart.splice(index, 1);
      state.checkoutKey = null;
      render();
    },
    submitRegister: function(ev){
      ev.preventDefault();
      var name = document.getElementById("reg-name").value.trim();
      var email = document.getElementById("reg-email").value.trim();
      var pass = document.getElementById("reg-pass").value;
      var pass2 = document.getElementById("reg-pass2").value;
      state.registerForm = { name: name, email: email, pass: pass, pass2: pass2 };
      if (!name || !email || !pass || !pass2){
        state.registerError = "Please fill in every field to finish registration.";
      } else if (email.indexOf("@") === -1 || email.indexOf(".") === -1){
        state.registerError = "That doesn\u2019t look like a valid email address.";
      } else if (pass.length < 6){
        state.registerError = "Password must be at least 6 characters.";
      } else if (pass !== pass2){
        state.registerError = "Passwords don\u2019t match \u2014 try again.";
      } else {
        state.registerError = "";
        api("POST", "/api/register", { name: name, email: email, pass: pass }).then(function(r){
          state.registerForm = { name: "", email: "", pass: "", pass2: "" };
          return startSession(r);
        }).catch(function(e){ state.registerError = e.message; render(); });
        return false;
      }
      render();
      return false;
    },
    submitLogin: function(ev){
      ev.preventDefault();
      var email = document.getElementById("log-email").value.trim();
      var pass = document.getElementById("log-pass").value;
      state.loginForm = { email: email, pass: pass };
      if (!email || !pass){
        state.loginError = "Enter both your email and password.";
      } else {
        state.loginError = "";
        api("POST", "/api/login", { email: email, pass: pass }).then(function(r){
          state.loginForm = { email: "", pass: "" };
          return startSession(r);
        }).catch(function(e){ state.loginError = e.message; render(); });
        return false;
      }
      render();
      return false;
    },
    logout: function(){
      if (TOKEN) api("POST", "/api/logout").catch(function(e){
        state.serverError = "Local sign-out completed, but the server could not revoke this session: " + e.message;
        render();
      });
      TOKEN = null; try { sessionStorage.removeItem("ph.token"); } catch(e){}
      state.authenticated = false;
      state.isAdmin = false;
      state.userEmail = "";
      state.userName = "";
      state.cart = [];
      state.afterCheckout = false;
      state.myOrders = [];
      state.checkoutKey = null;
      state.fulfillment = null;
      state.address = { street: "", city: "", zip: "" };
      state.payment = null;
      state.orderCode = null;
      go("home");
    },
    choosePickup: function(){ state.fulfillment = "pickup"; state.deliveryError = ""; go("payment"); },
    submitDelivery: function(ev){
      ev.preventDefault();
      var street = document.getElementById("d-street").value.trim();
      var city = document.getElementById("d-city").value.trim();
      var zip = document.getElementById("d-zip").value.trim();
      state.address = { street: street, city: city, zip: zip };
      if (!street || !city){
        state.deliveryError = "Please enter your street address and city / town so we can deliver your flowers.";
        render();
        return false;
      }
      state.deliveryError = "";
      state.fulfillment = "delivery";
      state.address = { street: street, city: city, zip: zip };
      go("payment");
      return false;
    },
    choosePayment: function(id){ state.payment = id; render(); },
    confirmOrder: function(){
      if (state.placing || !state.cart.length) return;
      state.placing = true; render();
      // REVISION 2: one key per checkout. If the same checkout is sent twice (double-click, slow network retry)
      // the server returns the first order instead of creating a duplicate.
      if (!state.checkoutKey) state.checkoutKey = "ck" + Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
      var fulfillment = state.fulfillment;
      api("POST", "/api/orders", {
        items: state.cart.reduce(function(items, line){
          if (!line.lineId) line.lineId = newLineId();
          var f = flowerById(line.id);
          var lineName = line.arrangementType === "custom" ? "Custom Bouquet" : (f ? f.name : "Flower");
          lineFlowers(line).forEach(function(item){
            items.push({
              id: item.id, qty: item.qty * line.qty, line_key: line.lineId, line_name: lineName,
              arrangement: line.arrangementType || "single", line_qty: line.qty,
              wrap_design: line.wrapChoice === "wrapped" ? line.wrapDesign : "",
              wrap_color: line.wrapColor || "", wrap_notes: line.wrapNotes || ""
            });
          });
          return items;
        }, []),
        fulfillment: state.fulfillment, address: state.address, payment: state.payment, key: state.checkoutKey
      }).then(function(r){
        // The order is now saved, so the cart is emptied. Items already ordered can never be checked out again.
        state.lastOrder = {
          items: state.cart.map(function(line){
            var f = flowerById(line.id), name = line.arrangementType === "custom" ? "Custom Bouquet" : (f ? f.name : "Flower");
            return { name: name, qty: line.qty, price: lineTotal(line) / line.qty };
          }),
          total: cartTotal(), payment: state.payment
        };
        state.placing = false; state.orderCode = r.code; state.lastFulfillment = fulfillment; state.afterCheckout = false;
        state.cart = []; state.fulfillment = null; state.payment = null; state.checkoutKey = null;
        state.address = { street: "", city: "", zip: "" };
        // show the order exactly as the server saved it (purchase type, wrapping ...); fall back to the cart summary if that fails
        state.savedOrder = null;
        api("GET", "/api/orders/mine").then(function(list){
          state.myOrders = list; state.savedOrder = list.filter(function(o){ return o.code === r.code; })[0] || null;
        }).catch(function(){}).then(function(){
          go("done"); loadProducts().then(render).catch(function(e){ state.serverError = e.message; render(); });
        });
      }).catch(function(e){
        state.placing = false; var msg = e.message;
        loadProducts().then(function(){
          state.screen = "cart"; state.notice = msg + " Your order was not placed."; window.scrollTo(0,0); render();
        }).catch(function(refreshError){
          state.serverError = "";
          state.screen = "cart"; state.notice = msg + " Your order was not placed. Stock refresh failed: " + refreshError.message; window.scrollTo(0,0); render();
        });
      });
    },
    openAdmin: function(){ loadAdmin().then(function(){ go("admin"); }).catch(showErr); },
    openOrders: function(){ api("GET", "/api/orders/mine").then(function(r){ state.myOrders = r; go("orders"); }).catch(showErr); },
    deleteProduct: function(id){
      if (!confirm("Remove this flower from the shop? Past orders are kept.")) return;
      api("DELETE", "/api/admin/products/" + id).then(loadProducts).then(loadAdmin).then(render).catch(showErr);
    },
    setTab: function(t){ state.adminTab = t; render(); },
    setStatus: function(code, status){
      api("PATCH", "/api/admin/orders/" + code, { status: status }).then(loadAdmin).then(render).catch(showErr);
    },
    cancelOrder: function(code){
      api("PATCH", "/api/admin/orders/" + code, { status: "Cancelled" }).then(loadAdmin).then(render).catch(showErr);
    },
    saveProduct: function(id){
      var price = parseFloat(document.getElementById("p-price-" + id).value);
      var qty = parseInt(document.getElementById("p-qty-" + id).value, 10);
      var available = document.getElementById("p-avail-" + id).value === "1";
      if (isNaN(price) || price < 0 || isNaN(qty) || qty < 0){ alert("Enter a valid price and quantity."); return; }
      api("PUT", "/api/admin/products/" + id, { price: price, qty: qty, available: available }).then(loadProducts).then(loadAdmin).then(render).catch(showErr);
    },
    newOrder: function(){
      state.fulfillment = null;
      state.address = { street: "", city: "", zip: "" };
      state.payment = null;
      state.orderCode = null;
      go("home");
    }
  };
  window.App = App;

  render();
  loadProducts().catch(function(e){ state.serverError = e.message; }).then(function(){
    if (!TOKEN) return;
    return api("GET", "/api/me").then(function(r){ applyUser(r.user); }).catch(function(e){
      if (TOKEN) state.serverError = e.message;
    });
  }).then(render);
})();