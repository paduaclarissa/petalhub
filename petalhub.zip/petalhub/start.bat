@echo off
title PetalHub server
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Download the LTS version from https://nodejs.org and try again. & pause & exit /b)
if not exist "node_modules\mysql2" (
  echo Installing packages, please wait...
  call npm install --fetch-retries=5 --fetch-retry-mintimeout=20000
)
echo.
echo Before continuing: start MySQL in the XAMPP Control Panel and import schema.sql in phpMyAdmin.
echo.
set /p DB_PASSWORD=MySQL root password (press Enter if none): 
if "%ADMIN_EMAIL%"=="" set ADMIN_EMAIL=admin@petalhub.com
if "%ADMIN_PASSWORD%"=="" set ADMIN_PASSWORD=petalhub2026
echo.
echo Starting PetalHub... open http://localhost:3000 in Chrome. Do not close this window.
node server.js
pause
