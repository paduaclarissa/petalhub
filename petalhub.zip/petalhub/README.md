# PetalHub - Online Flower Ordering System
Node.js + MySQL (XAMPP / phpMyAdmin). Needs Node.js 18 or newer.

## One-time setup
1. Install Node.js (LTS) from https://nodejs.org. Check with `node -v`.
2. Open the XAMPP Control Panel and Start **Apache** and **MySQL**.
3. Open http://localhost/phpmyadmin > **Import** tab > choose `schema.sql` > **Go**.
   The `petalhub` database with 5 tables should appear on the left.

## Run the system
Double-click **start.bat** (it installs the packages the first time, then asks for the MySQL password and an admin email/password).
Or in a terminal inside this folder:

    npm install
    set ADMIN_EMAIL=admin@petalhub.com
    set ADMIN_PASSWORD=petalhub2026
    node server.js

(XAMPP's MySQL usually has no password for `root`. If yours has one, also `set DB_PASSWORD=...`)

Then open **http://localhost:3000** in Chrome (not localhost/petalhub - that is Apache, not the system). Keep the terminal open while using it.

- Admin: log in with the admin email and password from the first run.
- Customer: click **Log in** > register a new account.

## Troubleshooting
- `Access denied` -> wrong `DB_PASSWORD`.
- `Cannot use the MySQL database` -> MySQL is not running or schema.sql was not imported.
- `EADDRINUSE` -> an old server is still running on port 3000; close it, or `set PORT=3001`.
- Optional settings: DB_USER, DB_HOST, DB_PORT, DB_NAME, PORT.

Do not include the `node_modules` folder when zipping the project.
