@echo off
title PetalHub server
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Download the LTS version from https://nodejs.org and try again. & pause & exit /b)
if not exist "node_modules\mysql2" (
  echo Installing packages, please wait...
  call npm install --fetch-retries=5 --fetch-retry-mintimeout=20000
)
echo.
echo Before continuing: start MySQL in the XAMPP Control Panel and import schema.sql in phpMyAdmin.
echo.
set /p DB_PASSWORD=MySQL root password (press Enter if none): 
set /p ADMIN_EMAIL=Admin email, first run only (Enter = admin@petalhub.com): 
set /p ADMIN_PASSWORD=Admin password, first run only (at least 6 characters): 
echo.
echo Starting PetalHub... open http://localhost:3000 in Chrome. Do not close this window.
node server.js
pause
